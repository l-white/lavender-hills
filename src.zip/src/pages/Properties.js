import React from "react";
import Property from '../components/Property';

const Properties = () => {
  return (
    <>
      <h1 style={{color:"#CD7F32"}}>Properties</h1>
      <Property />
  </>
  );
}

export default Properties;